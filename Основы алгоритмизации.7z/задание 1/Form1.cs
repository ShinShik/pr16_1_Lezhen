namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCount_Click_Click(object sender, EventArgs e)
        {
            string filePath = "text.txt";
            string searchWord = txtSearchWord.Text.ToLower();

            try
            {
                List<string> words = File.ReadAllText(filePath)
                    .Split(new char[] { ' ', '\n', '\r', '.', ',', ':', ';', '!', '?' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(w => w.ToLower())
                    .ToList();

                int count = words.Count(w => w == searchWord);

                MessageBox.Show($"����� \"{searchWord}\" ����������� {count} ���.");

            }
            catch (Exception ex)
            {
                MessageBox.Show("������: " + ex.Message);
            }
        }
    }
}
