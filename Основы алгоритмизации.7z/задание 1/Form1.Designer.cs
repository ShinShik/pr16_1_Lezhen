﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCount_Click = new Button();
            txtSearchWord = new TextBox();
            SuspendLayout();
            // 
            // btnCount_Click
            // 
            btnCount_Click.Location = new Point(340, 203);
            btnCount_Click.Name = "btnCount_Click";
            btnCount_Click.Size = new Size(75, 23);
            btnCount_Click.TabIndex = 0;
            btnCount_Click.Text = "button1";
            btnCount_Click.UseVisualStyleBackColor = true;
            btnCount_Click.Click += btnCount_Click_Click;
            // 
            // txtSearchWord
            // 
            txtSearchWord.Location = new Point(327, 174);
            txtSearchWord.Name = "txtSearchWord";
            txtSearchWord.Size = new Size(100, 23);
            txtSearchWord.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtSearchWord);
            Controls.Add(btnCount_Click);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCount_Click;
        private TextBox txtSearchWord;
    }
}
