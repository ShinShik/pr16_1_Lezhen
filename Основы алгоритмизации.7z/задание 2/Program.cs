﻿using System;
using System.Linq;
using System.IO;

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("Введите строки через запятую: ");
            string input = Console.ReadLine();
            string[] array = input.Split(',');
            int digitCount = array.SelectMany(x => x).Count(char.IsDigit);
            Console.WriteLine($"Количество цифр в массиве: {digitCount}");
            Console.WriteLine("Цифры в массиве: ");
            foreach (var digit in array.SelectMany(x => x).Where(char.IsDigit))
            {
                Console.WriteLine(digit);
            }
            Console.WriteLine("Элементы массива до символа '/'");
            foreach (var item in array.TakeWhile(x => !x.Contains('"')))
            {
                Console.WriteLine(item);
            }
            var result = array.SkipWhile(x => !x.Contains("/"))
                              .Select(x => new string(x.Select(c => char.IsLetter(c) ? char.IsUpper(c) ? char.ToLower(c) : char.ToUpper(c) : c).ToArray()))
                              .ToArray();
            Console.WriteLine("Элементы массива после символа ' / ' с измененным регистром:");
            foreach (var item in result)
            {
                Console.WriteLine(item);
            }

            File.WriteAllLines("output.txt", result);

        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }        
    }
}